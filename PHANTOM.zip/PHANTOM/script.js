// script.js

function startChallenge(type) {
    const challengeArea = document.getElementById('challenge-area');
    switch (type) {
        case 'repair':
            challengeArea.innerHTML = `
                <h2>Space Station Repair Challenge</h2>
                <p>You need to allocate resources to repair the oxygen generator. Choose wisely!</p>
                <button onclick="completeChallenge('repair')">Complete Challenge</button>
            `;
            break;
        case 'resource':
            challengeArea.innerHTML = `
                <h2>Resource Allocation Challenge</h2>
                <p>Distribute limited resources to maintain life support and research operations.</p>
                <button onclick="completeChallenge('resource')">Complete Challenge</button>
            `;
            break;
        case 'navigation':
            challengeArea.innerHTML = `
                <h2>Navigation Puzzle</h2>
                <p>Solve the puzzle to correct the space station's orbit path.</p>
                <button onclick="completeChallenge('navigation')">Complete Challenge</button>
            `;
            break;
    }
}

function completeChallenge(type) {
    const challengeArea = document.getElementById('challenge-area');
    switch (type) {
        case 'repair':
            challengeArea.innerHTML = `<p>Challenge completed! Oxygen generator is repaired.</p>`;
            break;
        case 'resource':
            challengeArea.innerHTML = `<p>Challenge completed! Resources allocated successfully.</p>`;
            break;
        case 'navigation':
            challengeArea.innerHTML = `<p>Challenge completed! Space station's orbit is corrected.</p>`;
            break;
    }
}

function startMindfulness(type) {
    const mindfulnessArea = document.getElementById('mindfulness-area');
    switch (type) {
        case 'breathing':
            mindfulnessArea.innerHTML = `
                <h2>Mindful Breathing</h2>
                <p>Focus on your breathing. Inhale... Exhale...</p>
                <button onclick="endMindfulness('breathing')">End Session</button>
            `;
            break;
        case 'visualization':
            mindfulnessArea.innerHTML = `
                <h2>Guided Visualization</h2>
                <p>Imagine yourself in a serene space, surrounded by stars and galaxies...</p>
                <button onclick="endMindfulness('visualization')">End Session</button>
            `;
            break;
        case 'stretching':
            mindfulnessArea.innerHTML = `
                <h2>Stretching Routine</h2>
                <p>Follow the on-screen cues to perform a series of stretches.</p>
                <button onclick="endMindfulness('stretching')">End Session</button>
            `;
            break;
    }
}

function endMindfulness(type) {
    const mindfulnessArea = document.getElementById('mindfulness-area');
    switch (type) {
        case 'breathing':
            mindfulnessArea.innerHTML = `<p>Mindfulness session completed. Feel the calmness.</p>`;
            break;
        case 'visualization':
            mindfulnessArea.innerHTML = `<p>Visualization session completed. Return to the present moment.</p>`;
            break;
        case 'stretching':
            mindfulnessArea.innerHTML = `<p>Stretching session completed. Your body feels refreshed.</p>`;
            break;
    }
}

// Smooth Scroll to sections
document.querySelectorAll('nav a').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });


    });
});

function toggleContentTab() {
    const contentTab = document.getElementById('content-tab');
    const mainContent = document.getElementById('main-content');
    
    if (contentTab.classList.contains('open')) {
        contentTab.classList.remove('open');
        contentTab.style.left = '-50%';
        mainContent.style.marginLeft = '0';
    } else {
        contentTab.classList.add('open');
        contentTab.style.left = '0';
        mainContent.style.marginLeft = '50%';
    }
}