// content-bar.js
function openContentBar() {
    document.getElementById("contentBar").style.left = "0";
  }
  
  function closeContentBar() {
    document.getElementById("contentBar").style.left = "-50%";
  }
  
  document.querySelectorAll('.content-bar a').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      e.preventDefault();
      const targetId = this.getAttribute('href').substring(1);
      document.getElementById(targetId).scrollIntoView({
        behavior: 'smooth'
      });
    });
  });